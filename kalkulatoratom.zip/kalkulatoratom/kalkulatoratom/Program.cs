﻿using System;
using System.Collections.Generic;

public class KalkulatorAtomowy
{
    public struct Atomy
    {
        public int Protony;
        public int Neutrony;
        public int Elektrony;
        public double MasaWKg;
    }

    private static Dictionary<int, (string Symbol, string Name)> elements = new Dictionary<int, (string, string)>
    {
        { 1, ("H", "Wodór") },
        { 2, ("He", "Hel") },
    };

    private const double MevToKg = 1.78266192e-36;
    private const double ProtonMassMev = 938.272;
    private const double NeutronMassMev = 939.565;
    private const double ElectronMassMev = 0.511;

    public Atomy ObliczanieAtomow(int LiczbaAtomowa, int Masa)
    {
        Atomy atomy = new Atomy();
        atomy.Protony = LiczbaAtomowa;
        atomy.Neutrony = Masa - LiczbaAtomowa;
        atomy.Elektrony = LiczbaAtomowa;
        atomy.MasaWKg = (atomy.Protony * ProtonMassMev + atomy.Neutrony * NeutronMassMev + atomy.Elektrony * ElectronMassMev) * MevToKg;
        return atomy;
    }

    public void WyswietlAtomy(Atomy atomy, int LiczbaAtomowa)
    {
        if (elements.TryGetValue(LiczbaAtomowa, out var element))
        {
            Console.WriteLine($"Nazwa: {element.Name}");
            Console.WriteLine($"Symbol: {element.Symbol}");
        }
        else
        {
            Console.WriteLine("Nieznany pierwiastek");
        }

        Console.WriteLine("Protony: " + atomy.Protony);
        Console.WriteLine("Neutrony: " + atomy.Neutrony);
        Console.WriteLine("Elektrony: " + atomy.Elektrony);
        Console.WriteLine("Masa atomu w kg: " + atomy.MasaWKg);
    }
}

class Program
{
    static void Main(string[] args)
    {
        KalkulatorAtomowy kalkulator = new KalkulatorAtomowy();

        Console.WriteLine("Podaj Liczbe Atomowa:");
        int liczbaAtomowa = int.Parse(Console.ReadLine());

        Console.WriteLine("Podaj mase:");
        int masa = int.Parse(Console.ReadLine());

        KalkulatorAtomowy.Atomy atomy = kalkulator.ObliczanieAtomow(liczbaAtomowa, masa);
        kalkulator.WyswietlAtomy(atomy, liczbaAtomowa);
    }
}


